<?php

namespace ClassesWithParents;

class E extends D
{
    use CTrait;
}
